import { randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import type { Express, Request, Response } from "express";
import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import * as db from "./db";

const scrypt = promisify(scryptCb);
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const ATTEMPT_LIMIT = 12;
const attempts = new Map<string, { count: number; until: number }>();
const usernameSchema = z.string().trim().min(2).max(24).regex(/^[\p{L}\p{N}_-]+$/u);

function normalizedUsername(value: string) { return value.normalize("NFKC").trim().toLocaleLowerCase("ko-KR"); }
function allowAttempt(req: Request, res: Response) {
  const key = req.ip || "unknown";
  const now = Date.now();
  let record = attempts.get(key);
  if (!record || record.until < now) { record = { count: 0, until: now + ATTEMPT_WINDOW_MS }; attempts.set(key, record); }
  record.count += 1;
  if (attempts.size > 10000) for (const [k, v] of attempts) if (v.until < now) attempts.delete(k);
  if (record.count <= ATTEMPT_LIMIT) return true;
  res.status(429).json({ error: "잠시 후 다시 시도해 주세요." });
  return false;
}
export async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const derived = await scrypt(password, salt, 64) as Buffer;
  return `scrypt$${salt.toString("hex")}$${derived.toString("hex")}`;
}
export async function verifyPassword(password: string, stored: string | null) {
  if (!stored) return false;
  const [algorithm, saltHex, keyHex] = stored.split("$");
  if (algorithm !== "scrypt" || !saltHex || !keyHex) return false;
  const expected = Buffer.from(keyHex, "hex");
  const actual = await scrypt(password, Buffer.from(saltHex, "hex"), expected.length) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
async function establishSession(user: NonNullable<Awaited<ReturnType<typeof db.getUserByOpenId>>>, req: Request, res: Response) {
  const token = await sdk.createSessionToken(user.openId, { name: user.name || user.username || "", expiresInMs: ONE_YEAR_MS });
  res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
}

export function registerLocalAuthRoutes(app: Express) {
  app.post("/api/auth/register", async (req, res) => {
    if (!sameOriginRequest(req, res)) return;
    if (!allowAttempt(req, res)) return;
    const body = z.object({ username: usernameSchema, password: z.string().min(8).max(128) }).safeParse(req.body);
    if (!body.success) { res.status(400).json({ error: "아이디(2~24자)와 비밀번호(8~128자)를 확인해 주세요." }); return; }
    const username = normalizedUsername(body.data.username);
    try {
      if (await db.getUserByUsername(username)) { res.status(409).json({ error: "이미 사용 중인 아이디예요." }); return; }
      const user = await db.createLocalUser(username, await hashPassword(body.data.password));
      if (!user) throw new Error("USER_CREATE_FAILED");
      await establishSession(user, req, res);
      res.status(201).json({ user: { id: user.id, username: user.username, name: user.name } });
    } catch (error: any) {
      if (error?.code === "ER_DUP_ENTRY") { res.status(409).json({ error: "이미 사용 중인 아이디예요." }); return; }
      console.error("[Auth] Registration failed", error instanceof Error ? error.message : "unknown");
      res.status(503).json({ error: "가입을 처리하지 못했어요. 잠시 후 다시 시도해 주세요." });
    }
  });
  app.post("/api/auth/login", async (req, res) => {
    if (!sameOriginRequest(req, res)) return;
    if (!allowAttempt(req, res)) return;
    const body = z.object({ username: z.string().min(1).max(80), password: z.string().min(1).max(128) }).safeParse(req.body);
    if (!body.success) { res.status(400).json({ error: "아이디와 비밀번호를 입력해 주세요." }); return; }
    try {
      const user = await db.getUserByUsername(normalizedUsername(body.data.username));
      if (!user || !(await verifyPassword(body.data.password, user.passwordHash))) { res.status(401).json({ error: "아이디 또는 비밀번호가 맞지 않아요." }); return; }
      await db.touchUser(user);
      await establishSession(user, req, res);
      res.json({ user: { id: user.id, username: user.username, name: user.name } });
    } catch (error) {
      console.error("[Auth] Login failed", error instanceof Error ? error.message : "unknown");
      res.status(503).json({ error: "로그인을 처리하지 못했어요. 잠시 후 다시 시도해 주세요." });
    }
  });
  app.post("/api/auth/logout", (_req, res) => {
    if (!sameOriginRequest(_req, res)) return;
    res.clearCookie(COOKIE_NAME, getSessionCookieOptions(_req));
    res.json({ success: true });
  });
}

function sameOriginRequest(req: Request, res: Response) {
  const origin = req.get("origin");
  const referer = req.get("referer");
  if (!origin) { res.status(403).json({ error: "요청 출처를 확인할 수 없어요." }); return false; }
  try {
    const parsedOrigin = new URL(origin).origin;
    if (referer && new URL(referer).origin !== parsedOrigin) { res.status(403).json({ error: "안전하지 않은 요청이에요." }); return false; }
    return true;
  } catch {
    res.status(403).json({ error: "요청 출처를 확인할 수 없어요." }); return false;
  }
}
