import { randomInt } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";

const groupIdSchema = z.number().int().positive();
const databaseError = (error: unknown): never => {
  if (error instanceof TRPCError) throw error;
  console.error("[Spending] Database request failed", error instanceof Error ? error.message : "unknown");
  throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "저장 중 문제가 생겼어요. 잠시 후 다시 시도해 주세요." });
};

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => {
      if (!ctx.user) return null;
      const { id, username, name, email, loginMethod, role, createdAt, lastSignedIn } = ctx.user;
      return { id, username, name, email, loginMethod, role, createdAt, lastSignedIn };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, getSessionCookieOptions(ctx.req));
      return { success: true } as const;
    }),
    deleteAccount: protectedProcedure.mutation(async ({ ctx }) => {
      try {
        await db.deleteAccount(ctx.user.id);
        ctx.res.clearCookie(COOKIE_NAME, getSessionCookieOptions(ctx.req));
        return { success: true } as const;
      } catch (error) { return databaseError(error); }
    }),
  }),
  spending: router({
    groups: protectedProcedure.query(async ({ ctx }) => {
      try { return await db.listGroupsForUser(ctx.user.id); } catch (error) { return databaseError(error); }
    }),
    createGroup: protectedProcedure.input(z.object({
      name: z.string().trim().min(2).max(80),
      limitAmount: z.number().int().min(100).max(100_000_000),
      startsAt: z.string().datetime(),
      endsAt: z.string().datetime(),
    })).mutation(async ({ ctx, input }) => {
      const start = new Date(input.startsAt);
      const end = new Date(input.endsAt);
      if (end <= start) throw new TRPCError({ code: "BAD_REQUEST", message: "종료일은 시작일보다 뒤여야 해요." });
      const inviteCode = randomInt(0, 36 ** 8).toString(36).toUpperCase().padStart(8, "0");
      try {
        const group = await db.createSpendingGroup({ name: input.name, inviteCode, ownerUserId: ctx.user.id, limitAmount: input.limitAmount, startsAt: start, endsAt: end });
        return { ...group, totalSpent: 0 };
      } catch (error) { return databaseError(error); }
    }),
    joinGroup: protectedProcedure.input(z.object({ inviteCode: z.string().trim().min(5).max(12).transform(value => value.toUpperCase()) })).mutation(async ({ ctx, input }) => {
      try {
        const group = await db.joinSpendingGroup(ctx.user.id, input.inviteCode);
        if (!group) throw new TRPCError({ code: "NOT_FOUND", message: "초대 코드를 다시 확인해 주세요." });
        return group;
      } catch (error) { return databaseError(error); }
    }),
    expenses: protectedProcedure.input(z.object({ groupId: groupIdSchema })).query(async ({ ctx, input }) => {
      try {
        if (!(await db.isGroupMember(input.groupId, ctx.user.id))) throw new TRPCError({ code: "FORBIDDEN", message: "이 그룹의 멤버만 볼 수 있어요." });
        const group = await db.getSpendingGroup(input.groupId);
        if (!group) throw new TRPCError({ code: "NOT_FOUND", message: "목표를 찾을 수 없어요." });
        return await db.listGroupExpenses(input.groupId, group.startsAt, group.endsAt);
      } catch (error) { return databaseError(error); }
    }),
    addExpense: protectedProcedure.input(z.object({ groupId: groupIdSchema, description: z.string().trim().min(1).max(120), amount: z.number().int().min(1).max(100_000_000) })).mutation(async ({ ctx, input }) => {
      try {
        if (!(await db.isGroupMember(input.groupId, ctx.user.id))) throw new TRPCError({ code: "FORBIDDEN", message: "그룹 멤버만 소비를 기록할 수 있어요." });
        const group = await db.getSpendingGroup(input.groupId);
        const now = new Date();
        if (!group || now < group.startsAt || now > group.endsAt) throw new TRPCError({ code: "BAD_REQUEST", message: "소비를 기록할 수 있는 목표 기간이 아니에요." });
        await db.addExpense({ ...input, userId: ctx.user.id });
        return { success: true } as const;
      } catch (error) { return databaseError(error); }
    }),
  }),
});

export type AppRouter = typeof appRouter;
