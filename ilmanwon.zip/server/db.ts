import { and, eq, gte, inArray, lte, ne, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, User, users, socialAccounts, groups, groupMembers, expenses } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod", "username", "passwordHash"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}
export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result[0];
}
export async function createLocalUser(username: string, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const openId = `local_${randomUUID()}`;
  await db.insert(users).values({ openId, username, passwordHash, name: username, loginMethod: "password", lastSignedIn: new Date() });
  return getUserByOpenId(openId);
}
export async function touchUser(user: User) {
  const db = await getDb();
  if (db) await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
}

export async function deleteAccount(userId: number) {
  const database = await getDb();
  if (!database) throw new Error("DATABASE_UNAVAILABLE");
  await database.transaction(async tx => {
    const ownedGroups = await tx.select({ id: groups.id }).from(groups).where(eq(groups.ownerUserId, userId));
    for (const { id: groupId } of ownedGroups) {
      const [successor] = await tx.select({ userId: groupMembers.userId }).from(groupMembers)
        .where(and(eq(groupMembers.groupId, groupId), ne(groupMembers.userId, userId)))
        .orderBy(groupMembers.joinedAt).limit(1);
      if (successor) {
        await tx.update(groups).set({ ownerUserId: successor.userId }).where(eq(groups.id, groupId));
      } else {
        await tx.delete(expenses).where(eq(expenses.groupId, groupId));
        await tx.delete(groupMembers).where(eq(groupMembers.groupId, groupId));
        await tx.delete(groups).where(eq(groups.id, groupId));
      }
    }
    await tx.delete(expenses).where(eq(expenses.userId, userId));
    await tx.delete(groupMembers).where(eq(groupMembers.userId, userId));
    await tx.delete(socialAccounts).where(eq(socialAccounts.userId, userId));
    await tx.delete(users).where(eq(users.id, userId));
  });
}

export async function listGroupsForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const rows = await db.select({ group: groups }).from(groupMembers).innerJoin(groups, eq(groupMembers.groupId, groups.id)).where(eq(groupMembers.userId, userId)).orderBy(sql`${groups.createdAt} desc`);
  const ids = rows.map(row => row.group.id);
  const sums = ids.length ? await Promise.all(rows.map(async ({ group }) => {
    const [sum] = await db.select({ groupId: expenses.groupId, total: sql<number>`coalesce(sum(${expenses.amount}), 0)` }).from(expenses).where(and(eq(expenses.groupId, group.id), gte(expenses.spentAt, group.startsAt), lte(expenses.spentAt, group.endsAt))).groupBy(expenses.groupId);
    return sum;
  })) : [];
  const totals = new Map(sums.map(row => [row.groupId, Number(row.total)]));
  return rows.map(row => ({ ...row.group, totalSpent: totals.get(row.group.id) ?? 0 }));
}
export async function createSpendingGroup(input: { name: string; inviteCode: string; ownerUserId: number; limitAmount: number; startsAt: Date; endsAt: Date }) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  await db.insert(groups).values(input);
  const [created] = await db.select().from(groups).where(eq(groups.inviteCode, input.inviteCode)).limit(1);
  if (!created) throw new Error("GROUP_CREATE_FAILED");
  await db.insert(groupMembers).values({ groupId: created.id, userId: input.ownerUserId });
  return created;
}
export async function joinSpendingGroup(userId: number, code: string) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const [group] = await db.select().from(groups).where(eq(groups.inviteCode, code)).limit(1);
  if (!group) return null;
  await db.insert(groupMembers).values({ groupId: group.id, userId }).onDuplicateKeyUpdate({ set: { groupId: group.id } });
  return group;
}
export async function isGroupMember(groupId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const [row] = await db.select({ id: groupMembers.id }).from(groupMembers).where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId))).limit(1);
  return Boolean(row);
}
export async function listGroupExpenses(groupId: number, startsAt: Date, endsAt: Date) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  return db.select({ expense: expenses, userName: users.name, username: users.username }).from(expenses).innerJoin(users, eq(expenses.userId, users.id)).where(and(eq(expenses.groupId, groupId), gte(expenses.spentAt, startsAt), lte(expenses.spentAt, endsAt))).orderBy(sql`${expenses.spentAt} desc`).limit(50);
}
export async function getSpendingGroup(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const [group] = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
  return group;
}
export async function addExpense(input: { groupId: number; userId: number; description: string; amount: number }) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  await db.insert(expenses).values(input);
}
