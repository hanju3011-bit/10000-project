import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./auth";

describe("local password credential handling", () => {
  it("stores a salted scrypt hash instead of the original password", async () => {
    const password = "mango-friend-1234";
    const first = await hashPassword(password);
    const second = await hashPassword(password);
    expect(first).toMatch(/^scrypt\$[a-f0-9]{32}\$[a-f0-9]{128}$/);
    expect(first).not.toContain(password);
    expect(second).not.toEqual(first);
    await expect(verifyPassword(password, first)).resolves.toBe(true);
    await expect(verifyPassword("other-password", first)).resolves.toBe(false);
  });

  it("rejects absent or malformed stored credentials", async () => {
    await expect(verifyPassword("anything", null)).resolves.toBe(false);
    await expect(verifyPassword("anything", "not-a-scrypt-hash")).resolves.toBe(false);
  });
});
