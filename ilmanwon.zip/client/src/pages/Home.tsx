import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowDownRight, ArrowRight, ArrowUpRight, Check, ChevronDown, ChevronRight, CirclePlus, Copy, CreditCard, Plus, ReceiptText, ShieldCheck, Sparkles, Users, WalletCards, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

type DialogKind = "login" | "signup" | "create" | "join" | "expense" | null;
const money = (value: number) => new Intl.NumberFormat("ko-KR").format(value);
const shortDate = (value: Date | string) => new Intl.DateTimeFormat("ko-KR", { month: "numeric", day: "numeric" }).format(new Date(value));
const localDateValue = (date: Date) => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};

function Mark({ small = false }: { small?: boolean }) {
  return <img className={small ? "brand-mark brand-mark-small" : "brand-mark"} src="/brand-logo.png" alt="" />;
}
function Brand() {
  return <a className="brand" href="/" aria-label="일만원 홈"><Mark /><span>일만원<span className="brand-dot">.</span></span></a>;
}
export default function Home() {
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const [dialog, setDialog] = useState<DialogKind>(null);
  const [loginMode, setLoginMode] = useState<"login" | "signup">("login");
  const [authError, setAuthError] = useState("");
  const [notice, setNotice] = useState("");
  const [activeGroupId, setActiveGroupId] = useState<number | null>(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [groupName, setGroupName] = useState("");
  const [groupLimit, setGroupLimit] = useState("10000");
  const [startDate, setStartDate] = useState(() => localDateValue(new Date()));
  const [endDate, setEndDate] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 6); return localDateValue(d); });
  const [inviteCode, setInviteCode] = useState("");
  const [expenseName, setExpenseName] = useState("");
  const [expenseAmount, setExpenseAmount] = useState("");

  const groups = trpc.spending.groups.useQuery(undefined, { enabled: Boolean(me.data), retry: false });
  const allGroups = groups.data ?? [];
  const activeGroup = allGroups.find(group => group.id === activeGroupId) ?? allGroups[0];
  const expenses = trpc.spending.expenses.useQuery({ groupId: activeGroup?.id ?? 0 }, { enabled: Boolean(activeGroup?.id), retry: false });
  const createGroup = trpc.spending.createGroup.useMutation({ onSuccess: async () => { await utils.spending.groups.invalidate(); setDialog(null); setGroupName(""); setNotice("우리의 목표를 만들었어요!"); } });
  const joinGroup = trpc.spending.joinGroup.useMutation({ onSuccess: async () => { await utils.spending.groups.invalidate(); setDialog(null); setInviteCode(""); setNotice("친구의 목표에 합류했어요."); } });
  const addExpense = trpc.spending.addExpense.useMutation({ onSuccess: async () => { await Promise.all([utils.spending.groups.invalidate(), utils.spending.expenses.invalidate()]); setDialog(null); setExpenseName(""); setExpenseAmount(""); setNotice("기록 완료! 약속을 잘 지키고 있어요."); } });
  const busy = createGroup.isPending || joinGroup.isPending || addExpense.isPending;

  useEffect(() => {
    try {
      const flash = sessionStorage.getItem("ilmanwon:flash");
      if (flash) { setNotice(flash); sessionStorage.removeItem("ilmanwon:flash"); }
      if (sessionStorage.getItem("ilmanwon:open-login") === "1") {
        sessionStorage.removeItem("ilmanwon:open-login");
        setNotice("프로필을 보려면 로그인해 주세요.");
        openAuth("login");
      }
    } catch { /* private mode */ }
  }, []);
  useEffect(() => { if (notice) { const id = window.setTimeout(() => setNotice(""), 3600); return () => window.clearTimeout(id); } }, [notice]);
  useEffect(() => { if (me.data) setDialog(null); }, [me.data]);

  const totalSpent = activeGroup?.totalSpent ?? 0;
  const remaining = Math.max((activeGroup?.limitAmount ?? 0) - totalSpent, 0);
  const progress = activeGroup?.limitAmount ? totalSpent / activeGroup.limitAmount : 0;
  const savedStatus = useMemo(() => {
    if (!activeGroup) return "함께할 목표를 만들어 보세요";
    if (totalSpent > activeGroup.limitAmount) return `한도를 ₩${money(totalSpent - activeGroup.limitAmount)} 넘었어요`;
    if (totalSpent === activeGroup.limitAmount) return "한도에 딱 맞게 지켰어요";
    if (progress >= 0.75) return "약속에 가까워지고 있어요";
    return "우리의 약속, 잘 지키는 중";
  }, [activeGroup, progress, totalSpent]);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setAuthError("");
    if (loginMode === "signup" && password !== confirmPassword) { setAuthError("비밀번호가 서로 달라요."); return; }
    try {
      const response = await fetch(`/api/auth/${loginMode === "signup" ? "register" : "login"}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "요청을 처리하지 못했어요.");
      await Promise.all([utils.spending.groups.reset(), utils.spending.expenses.reset()]);
      await utils.auth.me.invalidate(); await utils.auth.me.refetch();
      setDialog(null); setPassword(""); setConfirmPassword(""); setNotice(loginMode === "signup" ? "일만원에 오신 걸 환영해요!" : "다시 만나 반가워요.");
    } catch (error) { setAuthError(error instanceof Error ? error.message : "로그인을 처리하지 못했어요."); }
  }
  function openAuth(mode: "login" | "signup") { setLoginMode(mode); setAuthError(""); setUsername(""); setPassword(""); setConfirmPassword(""); setDialog(mode); }
  function submitCreateGroup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    createGroup.mutate({ name: groupName.trim(), limitAmount: Number(groupLimit.replace(/[^\d]/g, "")), startsAt: new Date(`${startDate}T00:00:00`).toISOString(), endsAt: new Date(`${endDate}T23:59:59`).toISOString() });
  }
  function submitExpense(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!activeGroup) return;
    addExpense.mutate({ groupId: activeGroup.id, description: expenseName.trim(), amount: Number(expenseAmount.replace(/[^\d]/g, "")) });
  }
  async function copyInvite() {
    if (!activeGroup) return;
    try { await navigator.clipboard.writeText(activeGroup.inviteCode); setNotice("초대 코드를 복사했어요."); }
    catch { setNotice(`친구에게 초대 코드 ${activeGroup.inviteCode}를 알려주세요.`); }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <Brand />
        <div className="topbar-right">
          {!me.data ? <><button type="button" className="nav-login" onClick={() => openAuth("login")}>로그인</button><button type="button" className="button button-dark button-nav-signup" onClick={() => openAuth("signup")}>회원가입 <ArrowRight size={15} /></button></> : <button type="button" className="profile-link" onClick={() => setLocation("/profile")} aria-label="프로필 열기"><span className="online-dot" />{me.data.name || me.data.username || "친구"}님</button>}
        </div>
      </header>

      {!me.data ? <main className="landing">
        <section className="hero-section">
          <div className="hero-copy">
            <span className="eyebrow"><Sparkles size={14} /> FRIENDS &amp; FINANCES</span>
            <h1>아끼는 건<br /><span className="headline-highlight">함께라서</span> 쉬우니까.</h1>
            <p className="hero-description">친구와 이번 달 한도를 정하고, 매일의 작은 선택을 함께 기록해요. 지출은 가볍게, 뿌듯함은 오래.</p>
            <div className="hero-actions"><button className="button button-dark button-large" onClick={() => openAuth("signup")}>우리 목표 만들기 <ArrowRight size={17} /></button><button className="text-action" onClick={() => openAuth("login")}>이미 계정이 있어요</button></div>
            <div className="hero-proof"><div className="avatar-stack"><span>민</span><span>서</span><span>유</span><span>+</span></div><span>친구와 같이, 나답게 쓰기</span></div>
          </div>
          <div className="hero-art" aria-label="소비 목표 예시">
            <div className="sunburst" />
            <div className="receipt-card">
              <div className="receipt-top"><span className="receipt-label">이번 주 우리 한도</span><span className="tiny-pill"><span className="online-dot" />함께하는 중</span></div>
              <div className="receipt-amount"><strong>₩28,400</strong><span>/ ₩50,000</span></div>
              <div className="progress-track"><span style={{ width: "57%" }} /></div>
              <div className="receipt-bottom"><span>아직 <b>₩21,600</b> 남았어요</span><span className="tiny-smile">잘하고 있어요!</span></div>
              <div className="receipt-divider" />
              <div className="friend-row"><div className="friend-avatar friend-peach">민</div><div className="friend-info"><b>민지</b><span>오늘은 커피 한 잔</span></div><span className="friend-spent">₩4,500</span><Check className="friend-check" size={15} /></div>
              <div className="friend-row"><div className="friend-avatar friend-blue">서</div><div className="friend-info"><b>서준</b><span>점심도 알뜰하게</span></div><span className="friend-spent">₩8,900</span><Check className="friend-check" size={15} /></div>
              <div className="friend-row"><div className="friend-avatar friend-green">나</div><div className="friend-info"><b>나</b><span>잘 지키는 중이에요</span></div><span className="friend-spent">₩15,000</span><Check className="friend-check" size={15} /></div>
              <div className="sticker-note"><span>✳</span> 우리 같이<br />잘하고 있어!</div>
            </div>
            <div className="art-caption"><span className="caption-mark"><Check size={13} /></span>이번 주도 약속대로, 멋지게.</div>
          </div>
          <span className="hero-side-note">A LITTLE BETTER, TOGETHER</span>
        </section>
        <section className="how-section" aria-labelledby="how-heading"><div className="section-heading"><span className="eyebrow">SMALL STEPS, REAL PROGRESS</span><h2 id="how-heading">한도는 같이 정하고,<br /><span>성취감도 같이 나눠요.</span></h2></div><div className="steps-row"><article className="step-card"><span className="step-no">01</span><span className="step-icon step-yellow"><Users size={20} /></span><h3>친구와 목표 만들기</h3><p>이번 주 한도를 정하고, 함께 지킬 친구를 초대해요.</p></article><span className="step-arrow"><ArrowRight size={19} /></span><article className="step-card"><span className="step-no">02</span><span className="step-icon step-mint"><ReceiptText size={20} /></span><h3>오늘의 소비 기록</h3><p>쓴 만큼 짧게 적어요. 우리 목표에 바로 반영돼요.</p></article><span className="step-arrow"><ArrowRight size={19} /></span><article className="step-card"><span className="step-no">03</span><span className="step-icon step-lilac"><Sparkles size={20} /></span><h3>작은 성취 느끼기</h3><p>남은 금액도, 약속을 지킨 오늘도 뿌듯하게.</p></article></div></section>
        <footer className="landing-footer"><Brand /><span>함께 정한 만큼, 가볍게 그리고 뿌듯하게.</span><span>© 일만원</span></footer>
      </main> : <main className="dashboard">
        <section className="dashboard-welcome"><div><span className="eyebrow"><span className="online-dot" />YOUR LITTLE WIN, TODAY</span><h1>오늘도, 잘하고 있어요<span className="period-dot">.</span></h1><p>우리의 약속을 한 번 확인해 볼까요?</p></div><button className="button button-dark welcome-record" onClick={() => activeGroup ? setDialog("expense") : setDialog("create")}><Plus size={17} /> 소비 기록</button></section>
        <section className="dashboard-content">
          <div className="dash-main-column">
            {groups.isLoading ? <div className="empty-card loading-card">목표를 불러오고 있어요…</div> : activeGroup ? <>
              {allGroups.length > 1 && <label className="group-select-label"><Users size={14} /><select value={activeGroup.id} onChange={event => setActiveGroupId(Number(event.target.value))}>{allGroups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}</select><ChevronDown size={14} /></label>}
              <article className="budget-card">
                <div className="budget-card-top"><span className="budget-eyebrow">{activeGroup.name} <span className="budget-dot">·</span> 함께 쓰는 한도</span><button className="share-code" onClick={copyInvite}><Copy size={13} /> 코드 <b>{activeGroup.inviteCode}</b></button></div>
                <div className="budget-numbers"><div><span className="budget-label">지금까지 쓴 금액</span><strong>₩{money(totalSpent)}</strong></div><div className="budget-total"><span>한도</span><b>₩{money(activeGroup.limitAmount)}</b></div></div>
                <div className="budget-progress"><div className="progress-track progress-large"><span style={{ width: `${Math.min(Math.max(progress * 100, totalSpent > 0 ? 2 : 0), 100)}%` }} /></div><div className="progress-labels"><span>{Math.round(progress * 100)}% 사용</span><span>{shortDate(activeGroup.startsAt)} — {shortDate(activeGroup.endsAt)}</span></div></div>
                <div className="remaining-strip"><span className="remaining-icon"><WalletCards size={17} /></span><span>우리에게 남은 금액</span><strong>₩{money(remaining)}</strong><span className="remaining-caption">{savedStatus}</span></div>
              </article>
              <div className="section-line"><div><span className="eyebrow">OUR PROMISE</span><h2>{progress > 1 ? "다음 선택은 함께 조정해요" : progress === 1 ? "한도에 딱 맞게 지켰어요" : "약속 지키는 중"} <span className="section-count">{allGroups.length ? "· 함께하고 있어요" : ""}</span></h2></div><button className="button button-quiet" onClick={copyInvite}><Copy size={14} /> 친구 초대</button></div>
              <article className="cheer-card"><span className="cheer-icon">{progress > 1 ? <ArrowUpRight size={17} /> : <Check size={17} />}</span><div><b>{progress > 1 ? `이번엔 한도를 ₩${money(totalSpent - activeGroup.limitAmount)} 넘었어요.` : progress === 1 ? "정한 한도를 정확히 지켰어요. 정말 멋져요." : "오늘의 작은 선택이 모이고 있어요."}</b><span>{progress > 1 ? "괜찮아요. 다음 목표는 친구와 함께 다시 조정해 봐요." : "이 목표를 함께 이어가고 있는 친구들과 한도를 지키는 중이에요."}</span></div><Sparkles size={18} className="cheer-sparkle" /></article>
              <div className="section-line expense-heading"><div><span className="eyebrow">LITTLE MOMENTS</span><h2>우리의 소비 기록</h2></div><button className="text-action compact" onClick={() => setDialog("expense")}>+ 기록하기</button></div>
              <div className="expense-list">{expenses.isLoading ? <div className="list-empty">소비 기록을 불러오는 중이에요.</div> : expenses.data?.length ? expenses.data.slice(0, 8).map(({ expense, userName, username: rowUsername }) => <div className="expense-row" key={expense.id}><div className="expense-glyph"><CreditCard size={17} /></div><div className="expense-details"><b>{expense.description}</b><span>{userName || rowUsername || "친구"} · {shortDate(expense.spentAt)}</span></div><strong>−₩{money(expense.amount)}</strong><Check size={15} className="expense-check" /></div>) : <div className="list-empty">아직 기록이 없어요. 첫 소비를 남겨볼까요?</div>}</div>
            </> : <section className="empty-card"><span className="empty-icon"><Users size={22} /></span><span className="eyebrow">A GOAL MADE TOGETHER</span><h2>아직 함께하는 목표가 없어요.</h2><p>친구와 소비 한도를 정하거나, 초대 코드로 목표에 참여해 보세요.</p><div className="empty-actions"><button className="button button-dark" onClick={() => setDialog("create")}><Plus size={17} /> 목표 만들기</button><button className="button button-outline" onClick={() => setDialog("join")}>초대 코드로 참여 <ArrowRight size={15} /></button></div></section>}
          </div>
          <aside className="dash-side-column"><article className="side-card encouragement"><span className="side-sun"><Sparkles size={17} /></span><span className="eyebrow">A KIND REMINDER</span><h3>아낀 만큼,<br />마음이 가벼워져요.</h3><p>완벽하게 아끼지 않아도 괜찮아요. 함께 정한 한도를 기억하는 것부터 시작이에요.</p><div className="side-card-foot"><span>나를 위한 작은 약속</span><ArrowUpRight size={15} /></div></article><article className="side-card side-stat"><div className="stat-icon"><ArrowDownRight size={16} /></div><div><span className="eyebrow">{activeGroup && totalSpent > activeGroup.limitAmount ? "한도 초과" : "남은 한도"}</span><strong>{activeGroup ? `₩${money(totalSpent > activeGroup.limitAmount ? totalSpent - activeGroup.limitAmount : remaining)}` : "목표와 함께 시작해요"}</strong><span>{activeGroup && totalSpent > activeGroup.limitAmount ? "함께 다시 조정해 봐요" : "우리의 다음 선택을 위해"}</span></div></article><button className="side-create" onClick={() => setDialog("create")}><CirclePlus size={16} /> 새로운 목표 만들기</button></aside>
        </section>
        <footer className="dashboard-footer"><Brand /><span>작은 약속이 만드는 든든한 뿌듯함.</span><span>© 일만원</span></footer>
      </main>}

      {notice && <div className="toast-note" role="status"><span className="toast-check"><Check size={14} /></span>{notice}<button onClick={() => setNotice("")} aria-label="알림 닫기"><X size={14} /></button></div>}
      {dialog && <div className="modal-backdrop" onClick={event => { if (event.target === event.currentTarget && !busy) setDialog(null); }}><section className="dialog-card" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><button className="dialog-close" type="button" onClick={() => setDialog(null)} aria-label="닫기"><X size={18} /></button>
        {(dialog === "login" || dialog === "signup") && <><Mark /><span className="eyebrow modal-eyebrow">{loginMode === "signup" ? "A FRESH START" : "GOOD TO SEE YOU"}</span><h2 id="dialog-title">{loginMode === "signup" ? "우리, 시작해 볼까요?" : "다시 만나 반가워요."}</h2><p className="dialog-intro">아이디로 간단히 시작하고, 친구와 함께 목표를 만들어요.</p><form className="form-stack" onSubmit={submitAuth}><label>아이디<input autoFocus autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} minLength={2} maxLength={24} required placeholder="아이디를 입력해 주세요" /></label><label>비밀번호<input autoComplete={loginMode === "signup" ? "new-password" : "current-password"} type="password" value={password} onChange={event => setPassword(event.target.value)} minLength={loginMode === "signup" ? 8 : 1} maxLength={128} required placeholder={loginMode === "signup" ? "8자 이상 입력해 주세요" : "비밀번호를 입력해 주세요"} /></label>{loginMode === "signup" && <label>비밀번호 확인<input autoComplete="new-password" type="password" value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} minLength={8} required placeholder="한 번 더 입력해 주세요" /></label>}{authError && <div className="form-error" role="alert">{authError}</div>}<button className="button button-dark button-full" >{loginMode === "signup" ? "가입하고 시작하기" : "로그인"}<ArrowRight size={16} /></button></form><div className="auth-switch">{loginMode === "signup" ? "이미 계정이 있나요?" : "아직 계정이 없나요?"}<button onClick={() => { setLoginMode(loginMode === "signup" ? "login" : "signup"); setAuthError(""); }}>{loginMode === "signup" ? "로그인" : "회원가입"}</button></div><div className="privacy-note"><ShieldCheck size={14} /> 비밀번호는 안전하게 해시 처리해 보관해요.</div></>}
        {dialog === "create" && <><span className="dialog-icon"><Users size={20} /></span><span className="eyebrow modal-eyebrow">MAKE A PROMISE</span><h2 id="dialog-title">우리의 목표 만들기</h2><p className="dialog-intro">친구와 함께 지킬 한도와 기간을 정해요.</p><form className="form-stack" onSubmit={submitCreateGroup}><label>목표 이름<input autoFocus value={groupName} onChange={event => setGroupName(event.target.value)} required minLength={2} maxLength={80} placeholder="예: 이번 주 점심비" /></label><label>함께 쓸 한도 (원)<input inputMode="numeric" value={groupLimit} onChange={event => setGroupLimit(event.target.value.replace(/[^\d]/g, ""))} required min={100} placeholder="10000" /></label><div className="date-fields"><label>시작일<input type="date" value={startDate} onChange={event => setStartDate(event.target.value)} required /></label><label>마감일<input type="date" value={endDate} onChange={event => setEndDate(event.target.value)} required /></label></div>{createGroup.error && <div className="form-error" role="alert">{createGroup.error.message}</div>}<button className="button button-dark button-full" disabled={busy}>목표 만들기 <ArrowRight size={16} /></button></form></>}
        {dialog === "join" && <><span className="dialog-icon dialog-icon-mint"><Users size={20} /></span><span className="eyebrow modal-eyebrow">JOIN YOUR FRIENDS</span><h2 id="dialog-title">초대 코드로 합류하기</h2><p className="dialog-intro">친구에게 받은 8자리 코드를 입력해 주세요.</p><form className="form-stack" onSubmit={event => { event.preventDefault(); joinGroup.mutate({ inviteCode: inviteCode.trim() }); }}><label>초대 코드<input autoFocus value={inviteCode} onChange={event => setInviteCode(event.target.value.toUpperCase())} required minLength={5} maxLength={12} placeholder="예: AB12CD34" /></label>{joinGroup.error && <div className="form-error" role="alert">{joinGroup.error.message}</div>}<button className="button button-dark button-full" disabled={busy}>목표에 참여하기 <ArrowRight size={16} /></button></form></>}
        {dialog === "expense" && <><span className="dialog-icon dialog-icon-peach"><ReceiptText size={20} /></span><span className="eyebrow modal-eyebrow">A LITTLE MOMENT</span><h2 id="dialog-title">오늘의 소비 기록</h2><p className="dialog-intro">{activeGroup?.name ?? "우리 목표"} 한도에 반영돼요.</p><form className="form-stack" onSubmit={submitExpense}><label>무엇에 썼나요?<input autoFocus value={expenseName} onChange={event => setExpenseName(event.target.value)} required maxLength={120} placeholder="예: 점심, 커피" /></label><label>얼마를 썼나요? (원)<input inputMode="numeric" value={expenseAmount} onChange={event => setExpenseAmount(event.target.value.replace(/[^\d]/g, ""))} required min={1} placeholder="4500" /></label>{addExpense.error && <div className="form-error" role="alert">{addExpense.error.message}</div>}<button className="button button-dark button-full" disabled={busy}>기록 남기기 <Check size={16} /></button></form></>}
      </section></div>}
    </div>
  );
}
