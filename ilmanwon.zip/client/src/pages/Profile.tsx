import { useEffect, useState } from "react";
import { AlertTriangle, ArrowLeft, CalendarDays, Check, LogOut, Mail, ShieldCheck, Trash2, UserRound } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

const joinedDate = (value: Date | string) => new Intl.DateTimeFormat("ko-KR", { year: "numeric", month: "long", day: "numeric" }).format(new Date(value));

export default function Profile() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const deleteAccount = trpc.auth.deleteAccount.useMutation();
  const [confirmText, setConfirmText] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!me.isPending && !me.data) {
      try { sessionStorage.setItem("ilmanwon:open-login", "1"); } catch { /* private mode */ }
      setLocation("/");
    }
  }, [me.data, me.isPending, setLocation]);

  async function clearPrivateCaches() {
    await Promise.all([utils.auth.me.reset(), utils.spending.groups.reset(), utils.spending.expenses.reset()]);
  }
  async function logout() {
    setError(""); setBusy(true);
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" });
      if (!response.ok) throw new Error("로그아웃하지 못했어요. 다시 시도해 주세요.");
      try { sessionStorage.setItem("ilmanwon:flash", "로그아웃했어요."); } catch { /* private mode */ }
      await clearPrivateCaches(); setLocation("/");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "로그아웃하지 못했어요."); }
    finally { setBusy(false); }
  }
  async function confirmDelete() {
    if (confirmText.trim() !== "탈퇴") return;
    setError(""); setBusy(true);
    try {
      await deleteAccount.mutateAsync();
      try { sessionStorage.setItem("ilmanwon:flash", "회원 탈퇴가 완료됐어요."); } catch { /* private mode */ }
      await clearPrivateCaches(); setLocation("/");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "회원 탈퇴를 완료하지 못했어요."); setBusy(false); }
  }

  if (me.isPending || !me.data) return <div className="profile-loading" role="status">프로필을 불러오고 있어요…</div>;
  const accountName = me.data.name || me.data.username || "일만원 친구";
  const authLabel = "아이디와 비밀번호";

  return (
    <div className="app-shell profile-shell">
      <header className="topbar profile-topbar">
        <a className="brand" href="/" aria-label="일만원 홈"><img className="brand-mark" src="/brand-logo.png" alt="" /><span>일만원<span className="brand-dot">.</span></span></a>
        <button type="button" className="profile-back" onClick={() => setLocation("/")}><ArrowLeft size={16} /> 홈으로</button>
      </header>
      <main className="profile-page">
        <section className="profile-heading">
          <span className="eyebrow">YOUR ACCOUNT</span>
          <h1>내 프로필</h1>
          <p>일만원에서 함께 만드는 작은 약속이에요.</p>
        </section>
        <section className="profile-card" aria-label="내 계정 정보">
          <div className="profile-identity"><span className="profile-avatar"><UserRound size={23} /></span><div><span className="eyebrow">MY ACCOUNT</span><h2>{accountName}</h2><p>일만원과 함께하고 있어요</p></div></div>
          <div className="profile-details">
            <div className="profile-detail"><span className="profile-detail-icon"><UserRound size={16} /></span><div><span>아이디</span><strong>{me.data.username || "아이디 정보가 없어요"}</strong></div></div>
            <div className="profile-detail"><span className="profile-detail-icon"><Mail size={16} /></span><div><span>이메일</span><strong>{me.data.email || "등록된 이메일이 없어요"}</strong></div></div>
            <div className="profile-detail"><span className="profile-detail-icon"><ShieldCheck size={16} /></span><div><span>로그인 방법</span><strong>{authLabel}</strong></div></div>
            <div className="profile-detail"><span className="profile-detail-icon"><CalendarDays size={16} /></span><div><span>함께한 날</span><strong>{joinedDate(me.data.createdAt)}</strong></div></div>
          </div>
        </section>
        <section className="profile-security-note"><span><Check size={16} /></span><p>계정 정보는 안전하게 보관되며, 친구와 함께한 목표는 탈퇴 전까지 계속 이어져요.</p></section>

        <section className="profile-actions-section" aria-labelledby="account-actions-heading">
          <span className="eyebrow">ACCOUNT ACTIONS</span>
          <h2 id="account-actions-heading">계정 관리</h2>
          <p>필요할 때 언제든 계정에서 나가거나 탈퇴할 수 있어요.</p>
          {error && <div className="form-error profile-error" role="alert">{error}</div>}
          <div className="profile-action-card profile-logout-card">
            <div className="profile-action-copy"><span className="profile-action-icon"><LogOut size={17} /></span><div><b>로그아웃</b><span>이 기기의 일만원 계정에서 로그아웃해요.</span></div></div>
            <button type="button" className="button button-outline" onClick={logout} disabled={busy}>로그아웃</button>
          </div>
          <div className="profile-action-card profile-delete-card">
            <div className="profile-action-copy"><span className="profile-action-icon profile-delete-icon"><Trash2 size={17} /></span><div><b>회원 탈퇴</b><span>계정과 내가 작성한 소비 기록을 삭제해요.</span></div></div>
            {!showDeleteConfirm ? <button type="button" className="button button-danger-outline" onClick={() => { setError(""); setShowDeleteConfirm(true); }}>탈퇴하기</button> : <div className="profile-delete-confirm" role="alert">
              <div className="profile-warning"><AlertTriangle size={17} /><p><strong>탈퇴하면 되돌릴 수 없어요.</strong><br />내 계정·프로필과 내가 기록한 소비는 삭제됩니다. 다른 멤버가 있는 목표는 남은 멤버에게 이어지고, 나 혼자 남은 목표와 그 기록은 함께 삭제됩니다.</p></div>
              <label className="delete-confirm-label">확인을 위해 <b>탈퇴</b>를 입력해 주세요<input autoComplete="off" value={confirmText} onChange={event => setConfirmText(event.target.value)} placeholder="탈퇴" /></label>
              <div className="delete-confirm-actions"><button type="button" className="button button-outline" disabled={busy} onClick={() => { setShowDeleteConfirm(false); setConfirmText(""); }}>취소</button><button type="button" className="button button-danger" disabled={busy || confirmText.trim() !== "탈퇴"} onClick={confirmDelete}>{busy ? "처리 중…" : "계정 탈퇴"}</button></div>
            </div>}
          </div>
        </section>
      </main>
    </div>
  );
}
