CREATE TABLE `spending_expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`groupId` int NOT NULL,
	`userId` int NOT NULL,
	`description` varchar(120) NOT NULL,
	`amount` int NOT NULL,
	`spentAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `spending_expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `spending_group_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`groupId` int NOT NULL,
	`userId` int NOT NULL,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `spending_group_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `group_member_unique` UNIQUE(`groupId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `spending_groups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(80) NOT NULL,
	`inviteCode` varchar(12) NOT NULL,
	`ownerUserId` int NOT NULL,
	`limitAmount` int NOT NULL,
	`startsAt` timestamp NOT NULL,
	`endsAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `spending_groups_id` PRIMARY KEY(`id`),
	CONSTRAINT `spending_groups_inviteCode_unique` UNIQUE(`inviteCode`)
);
--> statement-breakpoint
CREATE TABLE `social_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`provider` enum('google','apple') NOT NULL,
	`providerUserId` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `social_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `social_provider_identity_unique` UNIQUE(`provider`,`providerUserId`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `username` varchar(64);--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` text;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_username_unique` UNIQUE(`username`);--> statement-breakpoint
CREATE INDEX `expense_group_date_idx` ON `spending_expenses` (`groupId`,`spentAt`);--> statement-breakpoint
CREATE INDEX `expense_user_idx` ON `spending_expenses` (`userId`);--> statement-breakpoint
CREATE INDEX `member_user_idx` ON `spending_group_members` (`userId`);--> statement-breakpoint
CREATE INDEX `group_owner_idx` ON `spending_groups` (`ownerUserId`);--> statement-breakpoint
CREATE INDEX `social_user_idx` ON `social_accounts` (`userId`);