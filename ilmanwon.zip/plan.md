# 일만원 — 구현 계획

## 제품과 구현 방식

모바일 우선 한국어 웹앱. 기존 React 19 + Vite/Tailwind 프런트엔드, Express + tRPC API, Drizzle/MySQL 서버·관리형 DB를 재사용한다. 계정 인증은 아이디·비밀번호 방식만 제공한다. 가입 아이디와 scrypt 해시 비밀번호는 서버에 저장하고, 로컬 인증과 검증된 세션 JWT·`SameSite=None; Secure` 쿠키로 연결한다. Google·Apple 로그인 UI와 해당 제3자 OAuth 서버 경로는 제거한다. Preview가 제공하는 Manus 플랫폼 OAuth 경로는 Preview 세션 호환을 위해 유지한다. 기존 사용자·그룹·멤버십·지출 스키마와 이전의 연결 테이블은 데이터 손실을 피하도록 삭제하지 않으며, 이 앱에서는 새 소셜 로그인을 제공하지 않는다. tRPC는 인증된 사용자의 권한 범위를 검증하고 `auth.me` 응답에는 암호 해시·내부 openId를 포함하지 않는다.

로그아웃 방문자에게는 소개와 오른쪽 상단 로그인·회원가입 진입점을 보여준다. 가입·로그인 제출은 첫 세션 조회에 종속되지 않고, 모바일 버튼은 탭 가능한 최소 크기와 `touch-action: manipulation`을 갖도록 한다. 모달 닫기 같은 터치 가능한 상호작용은 클릭 이벤트로 처리한다. 로그인 회원은 이름을 눌러 프로필로 이동하며, 프로필 아래에서 로그아웃·회원 탈퇴를 할 수 있다. 탈퇴 시 본인 계정·연결된 레거시 관계·소비 기록·그룹 멤버십을 정리한다. 다른 회원이 남은 그룹은 소유권을 넘기며, 탈퇴자가 혼자 남은 그룹은 그룹과 관련 기록을 제거한다.

## 프로젝트 구조

- `client/src/pages/Home.tsx`: 랜딩·아이디 로그인/회원가입·친구 소비 목표 대시보드.
- `client/src/pages/Profile.tsx`: 프로필과 하단 계정 관리.
- `client/src/index.css`: 공통 스타일, 모바일 반응형 및 터치 타깃 규칙.
- `client/src/lib/trpc.ts`, `client/src/App.tsx`: API 클라이언트 및 홈/프로필 라우트.
- `client/public/brand-logo.png`: 사용자가 제공한 왕관·흰색 1K·라임 스우시 마크. favicon과 프로젝트 `app.config.ts`에서도 이를 사용한다.
- `server/auth.ts`: 아이디·비밀번호 가입, 로그인과 로그아웃.
- `server/_core/index.ts`: 로컬 계정 경로와 Preview 호환 Manus OAuth 및 앱 라우트 등록.
- `server/routers.ts`, `server/db.ts`: 그룹·소비·프로필·탈퇴 API 및 DB 쿼리.
- `drizzle/schema.ts`, `drizzle/0001_spending_accounts_groups.sql`: 영속 스키마와 추가형 migration.
- `client/public/manus-routes.json`: 공개 페이지 경로 선언.

## 디자인 방향

- **Design Movement:** 정돈된 동네 가계부와 활기 있는 현대 금융 앱을 합친 따뜻한 네오-브루탈리즘.
- **Core Principles:** 한 화면에서 한도와 남은 금액이 즉시 읽힌다; 소비 기록은 짧고 가볍다; 친구와의 공동 목표는 경쟁보다 격려를 중심에 둔다; 실제 인증·저장 상태를 정직하게 드러낸다.
- **Color Philosophy:** 종이 같은 아이보리와 먹색 글자에 레몬색 포인트, 차분한 청록 진행 표시를 결합해 절약을 벌칙이 아닌 작은 성공으로 표현한다.
- **Layout Paradigm:** 모바일 세로형 ‘목표 영수증’: 상단 브랜드·인증, 큰 잔액, 진행 트랙, 격려 메시지, 소비 내역. 프로필은 계정 정보 카드 아래 계정 작업을 두어 모바일에서 아래로 스크롤해 로그아웃·탈퇴하도록 한다. 넓은 화면은 콘텐츠와 보조 카드의 두 영역으로 확장한다.
- **Signature Elements:** 사용자 제공 왕관·1K·라임 스우시 로고, 테두리가 또렷한 목표 카드, 레몬·청록의 진행 트랙.
- **Interaction Philosophy:** 로그인 전에는 소개와 계정 진입을 즉시 쓸 수 있고, 인증 후에는 회원별 데이터만 표시한다. 터치 타깃을 충분히 크게 유지하고 화면 상태 변경은 클릭/탭 상호작용에 즉시 반응하게 한다. 성공은 작은 시각 피드백으로 알리며 탈퇴 전에는 영향·되돌릴 수 없음·명시 문구 입력을 안내한다.
- **Animation:** 입장 시 180ms 페이드, 기록 행은 140ms 진입, 진행률은 450ms ease-out. `prefers-reduced-motion`에서는 전환을 제거하며 불필요한 보상 대기 애니메이션을 두지 않는다.
- **Typography System:** 시스템 UI/Apple SD Gothic Neo/Malgun Gothic의 한국어 가독성과 고정폭 숫자. 잔액 36–48px, 섹션 제목 20px, 설명 14px, 보조 라벨 12px.
- **Brand Essence:** 친구들과 약속한 지출 한도를 같이 지키고 매일 작게 뿌듯해하는 모바일 가계부 — **따뜻한, 솔직한, 경쾌한**.
- **Brand Voice:** 평가 없이 응원하고 구체적인 금액으로 말한다. 예: “이번 주 우리 한도, 가볍게 지켜봐요.” / “잘했어요. 오늘도 약속한 만큼만 썼어요.”
- **Wordmark & Logo:** 사용자가 제공한 왕관·흰색 ‘1K’·라임색 스우시 이미지를 헤더, 프로필, 인증 창, favicon 및 프로젝트 로고에 일관되게 사용하고, 옆에 한글 ‘일만원’ 워드마크를 유지한다.
- **Signature Brand Color:** 약속을 상기시키는 레몬 `#F6D957`.

## 범위와 제한

친구 그룹의 동시접속 실시간 동기화나 알림은 별도 요청 전에는 제공한다고 약속하지 않는다. 로그인은 아이디·비밀번호만 제공하며 Google·Apple 로그인과 제3자 OAuth 경로는 제공하지 않는다. 공개 자동 배포는 꺼져 있으며 별도 게시 요청이 없어 Preview와 checkpoint까지만 진행한다.
